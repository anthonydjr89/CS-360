package com.example.eventtrackingapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DataDisplayActivity extends AppCompatActivity {

    private LinearLayout itemContainer;
    private int itemCount = 5; // initial 5 items

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display);

        // Find the container that holds all rows and the Add Data button
        itemContainer = findViewById(R.id.itemContainer);
        Button btnAddData = findViewById(R.id.btnAddData);

        // Set up delete listeners for the 5 static rows defined in XML

        // Row 1
        final LinearLayout row1 = findViewById(R.id.row1);
        Button btnDelete1 = findViewById(R.id.btnDelete1);
        btnDelete1.setOnClickListener(v -> {
            itemContainer.removeView(row1);
            Toast.makeText(DataDisplayActivity.this, "Item 1 deleted", Toast.LENGTH_SHORT).show();
        });

        // Row 2
        final LinearLayout row2 = findViewById(R.id.row2);
        Button btnDelete2 = findViewById(R.id.btnDelete2);
        btnDelete2.setOnClickListener(v -> {
            itemContainer.removeView(row2);
            Toast.makeText(DataDisplayActivity.this, "Item 2 deleted", Toast.LENGTH_SHORT).show();
        });

        // Row 3
        final LinearLayout row3 = findViewById(R.id.row3);
        Button btnDelete3 = findViewById(R.id.btnDelete3);
        btnDelete3.setOnClickListener(v -> {
            itemContainer.removeView(row3);
            Toast.makeText(DataDisplayActivity.this, "Item 3 deleted", Toast.LENGTH_SHORT).show();
        });

        // Row 4
        final LinearLayout row4 = findViewById(R.id.row4);
        Button btnDelete4 = findViewById(R.id.btnDelete4);
        btnDelete4.setOnClickListener(v -> {
            itemContainer.removeView(row4);
            Toast.makeText(DataDisplayActivity.this, "Item 4 deleted", Toast.LENGTH_SHORT).show();
        });

        // Row 5
        final LinearLayout row5 = findViewById(R.id.row5);
        Button btnDelete5 = findViewById(R.id.btnDelete5);
        btnDelete5.setOnClickListener(v -> {
            itemContainer.removeView(row5);
            Toast.makeText(DataDisplayActivity.this, "Item 5 deleted", Toast.LENGTH_SHORT).show();
        });

        // Set up the Add Data button to add a new row programmatically
        btnAddData.setOnClickListener(v -> {
            itemCount++;
            LinearLayout newRow = createRow(this, "Item " + itemCount);
            itemContainer.addView(newRow);
        });
    }

    // Helper method to create a new row (a horizontal LinearLayout with a TextView and a Delete button)
    @SuppressLint("SetTextI18n")
    private LinearLayout createRow(Context context, String text) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(16, 16, 16, 16);
        LayoutParams rowParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        row.setLayoutParams(rowParams);

        // Create and configure the TextView
        TextView tv = new TextView(context);
        LayoutParams tvParams = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1);
        tv.setLayoutParams(tvParams);
        tv.setText(text);
        tv.setTextSize(16);

        // Create and configure the Delete button
        Button btnDelete = new Button(context);
        LayoutParams btnParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        btnDelete.setLayoutParams(btnParams);
        btnDelete.setText("Delete");
        btnDelete.setOnClickListener(v -> {
            itemContainer.removeView(row);
            Toast.makeText(context, text + " deleted", Toast.LENGTH_SHORT).show();
        });

        // Add the TextView and Button to the row
        row.addView(tv);
        row.addView(btnDelete);

        return row;
    }
}
