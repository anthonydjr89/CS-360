package com.example.eventtrackingapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {

    private static final int REQUEST_SMS_PERMISSION = 100;
    private TextView tvPermissionStatus;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms);

        Button btnRequestSmsPermission = findViewById(R.id.btnRequestSmsPermission);
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);

        // Check if permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            tvPermissionStatus.setText("SMS Permission Granted");
        } else {
            tvPermissionStatus.setText("Permission not granted");
        }

        // Button to request SMS permission
        btnRequestSmsPermission.setOnClickListener(view -> requestSmsPermission());
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    REQUEST_SMS_PERMISSION
            );
        } else {
            // Already granted
            Toast.makeText(this, "Permission already granted.", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the permission request response
    @SuppressLint("SetTextI18n")
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                tvPermissionStatus.setText("SMS Permission Granted");
                Toast.makeText(this, "Permission granted. You will now receive SMS notifications.", Toast.LENGTH_SHORT).show();
                // Here, add code to schedule or send SMS notifications if needed
            } else {
                tvPermissionStatus.setText("Permission denied");
                Toast.makeText(this, "SMS Permission denied. Notifications will be disabled.", Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
