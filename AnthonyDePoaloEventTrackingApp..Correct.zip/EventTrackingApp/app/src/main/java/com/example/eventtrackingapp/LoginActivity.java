package com.example.eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);  // Use the layout we created (activity_login.xml)

        // Link UI elements
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);

        // Login button action
        btnLogin.setOnClickListener(view -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString();

            // Simple validation
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            } else {
                // For demo: assume login is successful, navigate to DataDisplayActivity
                Intent intent = new Intent(LoginActivity.this, DataDisplayActivity.class);
                startActivity(intent);
            }
        });

        // Create Account button action
        btnCreateAccount.setOnClickListener(view -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString();

            // For demo: just show a Toast; real app would add to a database
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please fill out both fields to create an account", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, "Account created (demo)", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
